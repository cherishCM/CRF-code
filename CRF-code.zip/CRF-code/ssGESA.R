#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("GSVA")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("GSEABase")

#install.packages("ggpubr")
#install.packages("reshape2")

library(limma)
library(GSVA)
library(GSEABase)
library(ggpubr)
library(reshape2)

expFile="fatigue-GEO30174-Matrix.txt"         #?????????ļ?
gmtFile="immune.gmt"         #???߻??????ļ?
riskFile="fatigue-risk.GEO30174.txt"     #?????ļ?
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\31.immFunction")     #???ù???Ŀ¼

#读取表达输入文件，并对输入文件进行整理
rt=read.table(expFile, header=T, sep="\t", check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
mat=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
mat=avereps(mat)
mat=mat[rowMeans(mat)>0,]
	
#读取免疫基因集文件
geneSet=getGmt(gmtFile, geneIdType=SymbolIdentifier())
	
#ssGSEA分析
ssgseaScore=gsva(mat, geneSet, method='ssgsea', kcdf='Gaussian', abs.ranking=TRUE)
#定义打分矫正函数
normalize=function(x){
	return((x-min(x))/(max(x)-min(x)))}
#对免疫相关功能的打分进行矫正
data=normalize(ssgseaScore)
ssgseaOut=rbind(id=colnames(data), data)
write.table(ssgseaOut, file="immFunScore.txt", sep="\t", quote=F, col.names=F)

#去除正常样品
#group=sapply(strsplit(colnames(data),"\\-"), "[", 4)
#group=sapply(strsplit(group,""), "[", 1)
#group=gsub("2", "1", group)
#data=t(data[,group==0])
#rownames(data)=gsub("(.*?)\\-(.*?)\\-(.*?)\\-(.*?)\\-.*", "\\1\\-\\2\\-\\3", rownames(data))
#data=avereps(data) #将重复值取均值
write.table(data, file="data.txt", sep="\t", quote=F, col.names=T)
#读取风险文件
risk=read.table(riskFile, header=T, sep="\t", check.names=F, row.names=1)
data2=read.table("data.txt", header=T, sep="\t", check.names=F, row.names=1)

#合并数据
sameSample=intersect(row.names(data2),row.names(risk))
data2=data2[sameSample,,drop=F]
risk=risk[sameSample,"Risk",drop=F]
rt1=cbind(data2, risk)

#将数据转换为箱线图输入文件
data=melt(rt1,id.vars=c("Risk"))
colnames(data)=c("Risk","Type","Score")
data$Risk=factor(data$Risk, levels=c("low","high"))

#绘制箱线图
p=ggboxplot(data, x="Type", y="Score", fill = "Risk",
     notch=T, outlier.shape = NA,
     xlab="",ylab="Score",add = "none", palette=c("blue","red") )
p=p+rotate_x_text(50)
p1=p+stat_compare_means(aes(group=Risk),symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", "")),label = "p.signif")

#输出文件
pdf(file="immFunction.pdf", width=8, height=6)
print(p1)
dev.off()
