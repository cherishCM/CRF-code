#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")


library(limma)              
expFile="GSE30174.share.txt"  
expFile="GSE14786.share.txt" 
expFile="GSE84437.share.txt" 
cliFile="GSE30174-Clinical.txt"  
cliFile="GSE14786-Clinical2.txt" 
cliFile="GEO84437-time.txt" 
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\18.geoMergeTime")    

#读取表达文件并对输入文件整理
rt=read.table(expFile, header=T, sep="\t", check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
data=avereps(data)
data=t(data)

#读取生存数据文件
cli=read.table(cliFile, header=T, sep="\t", check.names=F, row.names=1)

#数据合并
sameSample=intersect(row.names(data),row.names(cli))
data=data[sameSample,]
cli=cli[sameSample,]
out=cbind(cli,data)

#输出合并后结果
out=cbind(id=row.names(out),out)
write.table(out,file="GEO30174.expTime.txt",sep="\t",row.names=F,quote=F)


