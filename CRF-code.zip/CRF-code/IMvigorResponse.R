#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#install.packages("ggpubr")
#install.packages("pROC")

library(limma)
library(ggpubr)
library(pROC)

riskFile="risk.IMvigor.txt"        #风险文件
cliFile="IMvigor.Response.txt"     #临床数据文件?
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\36.IMvigorResponse")     #???ù???Ŀ¼

#读取风险文件?
risk=read.table(riskFile, header=T, sep="\t", check.names=F, row.names=1)
risk$riskScore[risk$riskScore>quantile(risk$riskScore,0.99)]=quantile(risk$riskScore,0.99)

#读取临床数据文件ļ?
cli=read.table(cliFile, header=T, sep="\t", check.names=F, row.names=1)

#合并数据?
samSample=intersect(row.names(risk), row.names(cli))
risk=risk[samSample,"riskScore",drop=F]
cli=cli[samSample,,drop=F]
rt=cbind(risk, cli)

#设置比较组?
clinical=colnames(rt)[2]
data=rt[c("riskScore", clinical)]
colnames(data)=c("riskScore", "clinical")
data=data[(data[,"clinical"]!="unknow"),]
group=levels(factor(data$clinical))
data$clinical=factor(data$clinical, levels=group)
comp=combn(group,2)
my_comparisons=list()
legen <-c("SD/PD","CR/PR")
for(i in 1:ncol(comp)){my_comparisons[[i]]<-comp[,i]}

#绘制箱线图ͼ
boxplot=ggboxplot(data, x="clinical", y="riskScore", color="clinical",
		          xlab="",
		          ylab="Risk score",
		          legend.title=clinical,
		          add = "jitter")+ 
	stat_compare_means(comparisons = my_comparisons)
	#stat_compare_means(comparisons = my_comparisons,symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", "ns")),label = "p.signif")

#输出图形?
pdf(file="boxplot.pdf", width=6, height=5)
print(boxplot)
dev.off()

############绘制ROC曲线############
y=ifelse(rt$binaryResponse=="SD/PD", 0, 1)
roc1=roc(y, as.numeric(rt[,"riskScore"]))
ci1=ci.auc(roc1, method="bootstrap")
ciVec=as.numeric(ci1)
pdf(file="ROC.pdf", width=5, height=4.8)
plot(roc1, print.auc=TRUE, col="red", legacy.axes=T)
text(0.39, 0.43, paste0("95% CI: ",sprintf("%.03f",ciVec[1]),"-",sprintf("%.03f",ciVec[3])), col="red")
dev.off()


