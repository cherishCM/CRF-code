if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("GenomicFeatures")
BiocManager::install("TxDb.Hsapiens.UCSC.hg19.knownGene")

install.packages("oncoPredict")
#install.packages ("parallel")

#引用包
library(limma)
library(oncoPredict)
library(parallel)
library(limma)
library(ggplot2)
library(ggpubr)
library(limma)
library(reshape2)
library(ggplot2)
library(ggpubr)

#setwd("F:/3SP/29oncoPredict")
#随机数种子
set.seed(999)

#读取输入文件
data=read.table("fatigue-GEO30174-Matrix.txt", header=T, sep="\t", check.names=F)
data=as.matrix(data)
rownames(data)=data[,1]
exp=data[,2:ncol(data)]
dimnames=list(rownames(exp),colnames(exp))
data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
data=avereps(data)
#转化为matrix
#dimnames=list(rownames(data), colnames(data))
#data=matrix(as.numeric(as.matrix(data)), nrow=nrow(data), dimnames=dimnames)
colnames(data)=gsub("(.*?)\\_(.*?)", "\\2", colnames(data))

#读取参考文件
GDSC2_Expr=readRDS(file='GDSC2_Expr.rds')
GDSC2_Res=readRDS(file = 'GDSC2_Res.rds')
GDSC2_Res=exp(GDSC2_Res) 

#药物敏感性,半小时左右
calcPhenotype(trainingExprData = GDSC2_Expr,    
              trainingPtype = GDSC2_Res,        
              testExprData = data,              
              batchCorrect = 'eb',  
              powerTransformPhenotype = TRUE,
              removeLowVaryingGenes = 0.2,    
              minNumSamples = 10,    
              printOutput = TRUE,    
              removeLowVaringGenesFrom = 'rawData')

#读入药敏文件
senstivity=read.csv("calcPhenotype_Output/DrugPredictions.csv", header=T, sep=",", check.names=F, row.names=1)
colnames(senstivity)=gsub("(.*)\\_(\\d+)", "\\1", colnames(senstivity))

#正常和肿瘤数目,第14,15字符,01-09是癌症，10-19是正常，20-29是癌旁
#group=sapply(strsplit(rownames(senstivity),"\\-"), "[", 4)
#group=sapply(strsplit(group,""), "[", 1)
#仅保留肿瘤样本
#senstivity = senstivity[group == 0,]

#转置
senstivity =t(senstivity)

#样本名仅保留前12字符
colnames(senstivity)=substr(colnames(senstivity),1,12)

#转置
senstivity =t(senstivity)


#读入风险文件
risk=read.table("fatigue-risk.GEO30174.txt", header=T, sep="\t", check.names=F, row.names=1)

#合并
sameSample=intersect(row.names(risk), row.names(senstivity))
risk=risk[sameSample, "Risk",drop=F]
senstivity=senstivity[sameSample,,drop=F]
senstivity[is.na(senstivity)] = 0
senstivity = log2(senstivity+1)
rt=cbind(risk, senstivity)

#设置比较组
rt$Risk=factor(rt$Risk, levels=c("low", "high"))
type=levels(factor(rt[,"Risk"]))
comp=combn(type, 2)
my_comparisons=list()
for(i in 1:ncol(comp)){my_comparisons[[i]]<-comp[,i]}

#提取显著差异的药物
sigGene=c()
for(i in colnames(rt)[2:(ncol(rt))]){
  if(sd(rt[,i])<0.05){next}
  wilcoxTest=wilcox.test(rt[,i] ~ rt[,"Risk"])
  pvalue=wilcoxTest$p.value
  if(wilcoxTest$p.value<0.001){
    sigGene=c(sigGene, i)
  }
}
sigGene=c(sigGene, "Risk")
rt=rt[,sigGene]

#把数据转换成ggplot2输入文件
rt=melt(rt,id.vars=c("Risk"))
colnames(rt)=c("Risk","Gene","Expression")

#设置比较组
group=levels(factor(rt$Risk))
rt$Risk=factor(rt$Risk, levels=c("low","high"))
comp=combn(group,2)
my_comparisons=list()
for(j in 1:ncol(comp)){my_comparisons[[j]]<-comp[,j]}

#绘制箱线图
boxplot=ggboxplot(rt, x="Gene", y="Expression", fill="Risk",
                  xlab="",
                  ylab="Drug Senstivity",
                  legend.title="Risk",
                  width=0.8,
                  palette = c("DodgerBlue1","Firebrick2") )+
  rotate_x_text(50)+
  stat_compare_means(aes(group=Risk),
                     method="wilcox.test",
                     symnum.args=list(cutpoints=c(0, 0.001, 0.01, 0.05, 1), 
                                      symbols=c("***", "**", "*", "ns")), label="p.signif")+
  theme(axis.text= element_text(face = "bold.italic",colour = "#441718",size = 16),
        axis.title = element_text(face = "bold.italic",colour = "#441718",size = 16),
        axis.line = element_blank(),
        plot.title = element_text(face = "bold.italic",colour = "#441718",size = 16),
        legend.text = element_text(face ="bold.italic"),
        panel.border = element_rect(fill=NA,color="#35A79D",size=1.5,linetype="solid"),
        panel.background = element_rect(fill = "#F1F6FC"),
        panel.grid.major = element_line(color = "#CFD3D6", size =.5,linetype ="dotdash" ),
        legend.title = element_text(face ="bold.italic",size = 13)
  )

#输出图片
pdf(file="drugSenstivity.pdf", width=20, height=8)
print(boxplot)
dev.off()
