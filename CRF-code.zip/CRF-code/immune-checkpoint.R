#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#install.packages("ggplot2")
#install.packages("ggpubr")
#install.packages("ggExtra")

library(limma)
library(ggplot2)
library(ggpubr)
library(ggExtra)

riskFile="fatigue-risk.GEO30174.txt"     #TCGA风险文件
expFile="fatigue-GEO30174-Matrix.txt"     #TCGA表达数据矩阵
gene="TNFRSF9"                  #基因标准名称
"TNFRSF9" %in% row.names(rt) #检查某个基因是否在data的行名中
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\28.riskGene")      

#读取表达数据文件
rt=read.table(expFile, header=T, sep="\t", check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp), colnames(exp))
data=matrix(as.numeric(as.matrix(exp)), nrow=nrow(exp), dimnames=dimnames)
data=avereps(data)
data=data[rowMeans(data)>0,]
	
#删掉正常样品
#group=sapply(strsplit(colnames(data),"\\-"), "[", 4)
#group=sapply(strsplit(group,""), "[", 1)
#group=gsub("2", "1", group)
#data=data[,group==0]
	
#提取目标基因表达量
data=rbind(data, gene=data[gene,])
exp=t(data[c("gene",gene),])
#row.names(exp)=gsub("(.*?)\\-(.*?)\\-(.*?)\\-.*", "\\1\\-\\2\\-\\3\\",  row.names(exp))
#exp=avereps(exp)
	
#??ȡ读取风险数据文件
risk=read.table(riskFile, header=T, sep="\t", check.names=F, row.names=1)
	
#?ϲ?合并数据
sameSample=intersect(row.names(exp), row.names(risk))
exp=exp[sameSample,]
exp=log2(exp+1)
risk=risk[sameSample,]
data=cbind(as.data.frame(exp), as.data.frame(risk))
	
#设置比较组
data$Risk=ifelse(data$Risk=="high", "High-risk", "Low-risk")
group=levels(factor(data$Risk))
data$Risk=factor(data$Risk, levels=c("Low-risk", "High-risk"))
comp=combn(group,2)
my_comparisons=list()
for(i in 1:ncol(comp)){my_comparisons[[i]]<-comp[,i]}
	
	
#绘制箱线图
boxplot=ggboxplot(data, x="Risk", y="gene", color="Risk",
			      xlab="",
			      ylab=paste0(gene, " expression"),
			      legend.title="",
			      palette = c("blue", "red"),
			      add = "jitter")+ 
	stat_compare_means(comparisons = my_comparisons)	
#输出箱线图
pdf(file="4-1BB-boxplot.pdf", width=4.5, height=4.25)
print(boxplot)
dev.off()
	
	
#????相关性分析
x=as.numeric(data[,"riskScore"])
y=as.numeric(data[,gene])
df1=as.data.frame(cbind(x,y))
p1=ggplot(df1, aes(x, y)) + 
		xlab("Risk score") + ylab(paste0(gene, " expression"))+
		geom_point() + geom_smooth(method="lm",formula = y ~ x) + theme_bw()+
		stat_cor(method = 'spearman', aes(x =x, y =y))
p2=ggMarginal(p1, type="density", xparams=list(fill = "orange"), yparams=list(fill = "blue"))
#????输出相关性图形
pdf(file="4-1BB-cor.pdf", width=4.5, height=4.25)
print(p2)
dev.off()


##