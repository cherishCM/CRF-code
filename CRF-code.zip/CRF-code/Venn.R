#install.packages("VennDiagram")
library(VennDiagram)  

geneList=list()
rt=read.table("PRAD-Diff-seq2.txt", header=T, sep="\t", check.names=F)
geneNames=as.vector(rt[,1])              
geneNames=gsub("^ | $","",geneNames)     
uniqGene=unique(geneNames)               
geneList[["PRAD-Diff-seq"]]=uniqGene 

rt=read.table("PRAD_T_diff.txt", header=T, sep="\t", check.names=F)
geneNames=as.vector(rt[,5])              
geneNames=gsub("^ | $","",geneNames)     
uniqGene=unique(geneNames)               
geneList[["PRAD_T_diff"]]=uniqGene 

rt=read.table("immune_gene.txt", header=F, sep="\t", check.names=F)
geneNames=as.vector(rt[,1])              
geneNames=gsub("^ | $","",geneNames)     
uniqGene=unique(geneNames)              
geneList[["Immune_gene"]]=uniqGene      

?venn.diagram
venn.plot=venn.diagram(geneList,filename=NULL,fill=c("cornflowerblue","yellowgreen"),scaled=FALSE,cat.col = c("cornflowerblue","yellowgreen"),col = "transparent", margin = 0.05, cat.cex = 1.2)
pdf(file="venn.pdf", width=5, height=5)
grid.draw(venn.plot)
dev.off()

interGenes=Reduce(intersect, geneList)
write.table(interGenes, file="interGene.txt", sep="\t", quote=F, col.names=F, row.names=F)
