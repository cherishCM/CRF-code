
#install.packages("survival")
#install.packages("regplot")
#install.packages("rms")

#加载包
library(survival)
library(regplot)
library(rms)
library(foreign) 
#设置工作目录
#setwd("F:/3SP/21Nomogram")

#读取风险输入文件
risk=read.table("risk.GEO.txt", header=T, sep="\t", check.names=F, row.names=1)

#读取临床数据文件
#cli=read.table("clinical2.txt", header=T, sep="\t", check.names=F, row.names=1)
#删除包含unknow的样本
#cli=cli[apply(cli,1,function(x)any(is.na(match('unknow',x)))),,drop=F]
#将年龄这一列转化为数值型

#合并数据
#samSample=intersect(row.names(risk), row.names(cli))
#risk1=risk[samSample,,drop=F]
#cli=cli[samSample,,drop=F]
colnames(risk)
#rt=cbind(risk1[,c("futime", "fustat", "Risk")], cli)
#rt=cbind(risk1[,c("time", "state", "riskScore")], cli)
rt=cbind(risk)
colnames(rt)
#rt$Mn=as.numeric(rt$Mn)
#cox回归
attach(rt)
dd<-datadist(rt)
options(datadist='dd')
res.cox=lrm(outcome ~ RUNX3+FKBP5+SYTL3+FGFBP2+DUSP2+MS4A7
            +IL2RB+LCP1+Risk, data = rt
              )
#绘制列线图
summary(res.cox)
na.omit(rt)
#单项得分，即图中的Points，表示每个变量在不同取值下所对应的单项分数，
#总得分，即Total Point，表示所有变量取值后对应的单项分数加起来合计的总得分。
#预测概率
nom1=regplot(res.cox,
             clickable=F,
             title="",
             points=TRUE,
             droplines=TRUE,
             observation=rt[50,],
             rank="sd",
             failtime = c(1,3,5),
             prfail = F,
             showP = T)
?regplot
#列线图打分
nomoRisk=predict(res.cox, data=rt, type="risk")
rt=cbind(risk1, Nomogram=nomoRisk)
outTab=rbind(ID=colnames(rt), rt)
write.table(outTab, file="nomoRisk.txt", sep="\t", col.names=F, quote=F)
