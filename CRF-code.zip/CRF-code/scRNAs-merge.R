if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
BiocManager::install("limma")
#???ð?
library("limma")
outFile="merge.txt"       #?????ļ????ļ?
#setwd("C:\\Users\\lexb\\Desktop\\communication\\17.scRNAmerge")     #???ù???Ŀ¼
files=dir()                             #??ȡĿ¼???????ļ?
files=grep("csv$", files, value=T)      #提取当前工作路径下所有以txt结尾的文件?

#?获取交集基因?
geneList=list()
for(i in 1:length(files)){
    inputFile=files[i]
    if(inputFile==outFile){next}
    rt=read.csv(inputFile, header=T, sep=",", check.names=F)
    header=unlist(strsplit(inputFile, "\\.|\\-|\\_"))
    if("TP53" %in% row.names(rt) | "GAPDH" %in% row.names(rt) | "CCL4" %in% row.names(rt)){
    	geneList[[header[1]]]=row.names(rt)
    }else{
    	geneList[[header[1]]]=as.vector(rt[,1])
    }
}
interGenes=Reduce(intersect, geneList)
#head(rt)
#summary(rt)
#数据合并?
allTab=data.frame()
for(i in 1:length(files)){
  inputFile=files[i]
  if(inputFile==outFile){next}
  header=unlist(strsplit(inputFile, "\\.|\\-|\\_"))
  #??ȡ?????ļ????????????ļ?????????
  rt=read.csv(inputFile, header=T, sep=",", check.names=F)
  if("TP53" %in% row.names(rt) | "GAPDH" %in% row.names(rt) | "CCL4" %in% row.names(rt)){
    rt=avereps(rt)
  }else{
    
    rt=as.matrix(rt)
    rownames(rt)=rt[,1]
    exp=rt[,2:ncol(rt)]
    dimnames=list(rownames(exp),colnames(exp))
    data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
    rt=avereps(data)
    
  }
  colnames(rt)=paste0(header[1], "_", colnames(rt))
  
  #???ݺϲ?
  if(ncol(allTab)==0){
    allTab=rt[interGenes,]
  }else{
    allTab=cbind(allTab, rt[interGenes,])
  }
}

#数据输出?
outTab=rbind(geneNames=colnames(allTab), allTab)
write.table(outTab, file=outFile, sep="\t", quote=F, col.names=F)
