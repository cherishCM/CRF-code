#install.packages("Seurat")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("GSVA")
#BiocManager::install("GSEABase")
#BiocManager::install("limma")
#BiocManager::install("SingleR")
#BiocManager::install("celldex")
#BiocManager::install("monocle")
#BiocManager::install(c("ExperimentHub"))

library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(celldex)
library(SingleR)
library(monocle)
####参考基因组id转换gtf文件 https://www.dazhuanLan.com/insafe/topics/975998#BiocManager: 
# # # # https://www.dazhuanLan.com/insafe/topics/975998#
#BiocManager::install("rtracklayer")
#library(rtracklayer)
#gtf=rtracklayer::import('gencode.v32.primary_assembly.annotation.gtf.gz')
#help("Deprecated")

#######################01.数据处理与准备??#######################
#???ð?
logFCfilter=1               #设置logFC?Ĺ???????
adjPvalFilter=0.05          #设置pvalue?Ĺ???????
inputFile="merge.txt"       #读取单细胞数据文件
geneFile="hubGenes.csv"     #读取Hub基因文件
#setwd("C:\\Users\\lexb\\Desktop\\communication\\18.Seurat")        #???ù???Ŀ¼

#??ȡ读取输入文件，并对文件进行处理?ļ?????????
rt=read.table(inputFile, header=T, sep="\t", check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
data=avereps(data)
rm(exp, rt)
#rm(exp, rt, gtf)
#将矩阵转换为Seurat包处理对象??й???
pbmc=CreateSeuratObject(counts=data, project="seurat", min.cells=3, min.features=50, names.delim = "_")
#使用PercentageFeatureSet?计算线粒体基因百分比ֱ?
pbmc[["percent.mt"]] <- PercentageFeatureSet(object = pbmc, pattern = "^MT-")
#??绘制基因特征小提琴图???ͼ
pdf(file="01.featureViolin.pdf", width=15, height=8)
VlnPlot(object = pbmc, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
dev.off()
pbmc=subset(x = pbmc, subset = nFeature_RNA > 50 & percent.mt < 5)    #??对数据进行过滤，基因数目>50，线粒体基因百分比<5可以改为10??
#rm(data)
#??绘制测序深度相关性图像ͼ??
pdf(file="01.featureCor.pdf", width=13, height=7)
plot1 <- FeatureScatter(object = pbmc, feature1 = "nCount_RNA", feature2 = "percent.mt",pt.size=1.5) #线粒体基因含量与测序深度相关性的图像
plot2 <- FeatureScatter(object = pbmc, feature1 = "nCount_RNA", feature2 = "nFeature_RNA",pt.size=1.5) #测序深度与基因数目相关性的图像
CombinePlots(plots = list(plot1, plot2))
dev.off()
#?对数据进行标准化处理??
pbmc <- NormalizeData(object=pbmc, normalization.method="LogNormalize", scale.factor=10000)
#?提前细胞间变异系数较大的基因???
pbmc <- FindVariableFeatures(object=pbmc, selection.method="vst", nfeatures=1500) #取变异系数最大的1500个基因
#??输出特征方差图???ͼ
top10 <- head(x = VariableFeatures(object = pbmc), 10)
pdf(file="01.featureVar.pdf",width=10,height=6)
plot1 <- VariableFeaturePlot(object = pbmc)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE) #将波动前10的基因名称进行标注
CombinePlots(plots = list(plot1, plot2))
dev.off()



#######################02.PCA主成分分析??#######################
##PCA分析??分析的目的是在细胞聚类之前对数据进行降维
pbmc=ScaleData(pbmc)        #PCA降维之前的标准预处理�??
pbmc=RunPCA(object= pbmc, npcs=20, pc.genes=VariableFeatures(object = pbmc))     #取波动最大的1500个基因进行PCA分析??

#??绘制每个PCA成分的特征基因???
pdf(file="02.pcaGene.pdf", width=10, height=8)
VizDimLoadings(object = pbmc, dims = 1:4, reduction = "pca", nfeatures=20)
dev.off()

#绘制主成分分析图像??ͼ??
pdf(file="02.PCA.pdf", width=7.5, height=5)
DimPlot(object=pbmc, reduction="pca")
dev.off()

#?绘制主成分分析热图???ͼ
pdf(file="02.pcaHeatmap.pdf", width=10, height=8)
DimHeatmap(object = pbmc, dims = 1:4, cells = 500, balanced = TRUE,nfeatures = 30,ncol=2)
dev.off()

#?得到每个PC的P值分布??pֵ?ֲ?
pbmc <- JackStraw(object = pbmc, num.replicate = 100)
pbmc <- ScoreJackStraw(object = pbmc, dims = 1:20)
pdf(file="02.pcaJackStraw.pdf",width=8,height=6)
JackStrawPlot(object=pbmc, dims=1:20)
dev.off()



#######################03.TSNE聚类分析和?marker基因?#######################
##TSNE聚类分析??
pcSelect=20  #选择PC的数目
pbmc <- FindNeighbors(object = pbmc, dims = 1:pcSelect)     #计算邻接距离??
pbmc <- FindClusters(object = pbmc, resolution = 0.5)       #?对细胞分组，对细胞标准模块进行可视化??׼ģ?黯
head(pbmc)
pbmc <- RunTSNE(object = pbmc, dims = 1:pcSelect)           #TSNE聚类??
pbmc <- RunUMAP(object = pbmc, dims = 1:pcSelect)   
pdf(file="03.TSNE.pdf",width=6.5,height=6)
#pdf(file="03.UMAP.pdf",width=6.5,height=6)
TSNEPlot(object = pbmc, pt.size = 2, label = TRUE)    #TSNE可视化ӻ?
#options(repr.plot.width = 6, repr.plot.height = 5)
#DimPlot(object = pbmc, reduction = "umap")
dev.off()
write.table(pbmc$seurat_clusters,file="03.tsneCluster.txt",quote=F,sep="\t",col.names=F) #记录细胞属于哪一个cluster

##??查找每一个聚类的差异基因???
pbmc.markers <- FindAllMarkers(object = pbmc,
                               only.pos = FALSE,
                               min.pct = 0.25,
                               logfc.threshold = logFCfilter)
sig.markers=pbmc.markers[(abs(as.numeric(as.vector(pbmc.markers$avg_log2FC)))>logFCfilter & as.numeric(as.vector(pbmc.markers$p_val_adj))<adjPvalFilter),]
#导出每个聚类的差异基因
write.table(sig.markers,file="03.clusterMarkers.txt",sep="\t",row.names=F,quote=F)
#对每一个聚类只挑表达前十的基因
top10 <- pbmc.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)
#??绘制marker在每一个cluster的热图?ͼ
pdf(file="03.tsneHeatmap.pdf",width=15, height=15)
DoHeatmap(object = pbmc, features = top10$gene) + NoLegend()
dev.off()
#rm(pbmc.markers, top10)

#######################04.SingleR R包注释细胞类型???#######################
pbmc_for_SingleR <- GetAssayData(pbmc, layer ="data")
clusters<-pbmc@meta.data$seurat_clusters
head(clusters)
ref=get(load("ref_Human_all.RData"))
#ref=celldex::HumanPrimaryCellAtlasData() #利用celldex包从后台下载配置文件
#?celldex::HumanPrimaryCellAtlasData
#monaco.ref <- celldex::Novershtern HematopoieticData
#ref <- celldex::BlueprintEncodeData()
#ref <- celldex::NovershternHematopoieticData()
singler=SingleR(test=pbmc_for_SingleR, ref =ref,
                labels=ref$label.main, clusters = clusters) #对cluster进行注释
head(singler)
clusterAnn=as.data.frame(singler)
clusterAnn=cbind(id=row.names(clusterAnn), clusterAnn)
clusterAnn=clusterAnn[,c("id", "labels")]
write.table(clusterAnn,file="04.clusterAnn.txt",quote=F,sep="\t", row.names=F) #导出cluster注释结果
#??输出细胞注释结果Ľ???
cellAnn=c()
for(i in 1:length(pbmc$seurat_clusters)){
  index=pbmc$seurat_clusters[i]
  cellAnn=c(cellAnn, clusterAnn[index,2])
}
cellAnnOut=cbind(names(pbmc$seurat_clusters), cellAnn)
colnames(cellAnnOut)=c("id", "labels")
#write.table(cellAnnOut, file="04.cellAnn-TSNE.txt", quote=F, sep="\t", row.names=F)
write.table(cellAnnOut, file="04.cellAnn-UMAP.txt", quote=F, sep="\t", row.names=F)
#??输出矫正的表达矩阵文件?ļ?
expMatrix=as.matrix(pbmc@assays$RNA$data)
head(expMatrix)
expMatrix=cbind(id=row.names(expMatrix), expMatrix)
#write.table(expMatrix, file="04.expMatirx-TSNE.txt", quote=F, sep="\t", row.names=F)
write.table(expMatrix, file="04.expMatirx-UMAP.txt", quote=F, sep="\t", row.names=F)

#ϸ细胞注释后的可视化??ӻ?
newLabels=singler$labels
names(newLabels)=levels(pbmc)
pbmc=RenameIdents(pbmc, newLabels)
#pdf(file="04.TSNE.pdf",width=7.5,height=6)
pdf(file="04.UMAP3.pdf", width=7.5,height=6)
#TSNEPlot(object = pbmc, pt.size = 2, label = TRUE)    #TSNE可视化ӻ?
options(repr.plot.width = 6, repr.plot.height = 5)
DimPlot(pbmc, reduction = "umap", label = T)& NoAxes()
dev.off()

##ϸ??细胞类型的差异分析??
pbmc.markers=FindAllMarkers(object = pbmc,
                            only.pos = FALSE,
                            min.pct = 0.25,
                            logfc.threshold = logFCfilter)
sig.cellMarkers=pbmc.markers[(abs(as.numeric(as.vector(pbmc.markers$avg_log2FC)))>logFCfilter & as.numeric(as.vector(pbmc.markers$p_val_adj))<adjPvalFilter),]
write.table(sig.cellMarkers,file="04.cellMarkers.txt",sep="\t",row.names=F,quote=F)



#######################05.核心基因可视化??ӻ?#######################
#?读取核心基因列表?б?
geneRT=read.csv(geneFile, header=T, sep=",", check.names=F)
hubGenes=as.vector(geneRT[,1])
#?绘制marker小提琴图??ͼ
pdf(file="05.hubGeneViolin.pdf", width=20, height=16)
VlnPlot(object = pbmc, features = hubGenes)
dev.off()

#?绘制marker在每个cluster的散点图?ͼ
hubGenes <- hubGenes[-c(1,7)]
pdf(file="05.hubGeneScatter.pdf", width=14, height=10)
pdf(file="05.hubGeneScatter-UMAP.pdf", width=14, height=10)
FeaturePlot(object = pbmc, features = hubGenes, cols = c("green", "red"))
dev.off()

#绘制marker在每个cluster的气泡图ͼ
pdf(file="05.hubGeneBubble-UMAP.pdf", width=15, height=8)
DotPlot(object = pbmc, features = hubGenes)
dev.off()
