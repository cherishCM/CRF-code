#install.packages('survival')
#install.packages("survminer")

library(survival)
library(survminer)
library(rms)
coxPfilter=0.05                  #生存分析过滤条件
inputFile="GEO14786.expTime2.txt"
inputFile="GEO30174.expTime.txt"
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\19.uniCox")     

#读取输入文件
rt=read.table(inputFile, header=T, sep="\t", check.names=F, row.names=1)
#rt$futime=rt$futime/365
colnames(rt)[106] <- "HLA"
#rt <- rt[,-77]
#对基因进行循环，查找预后相关基因
dd <- datadist(rt)
options(datadist='dd')
outTab=data.frame()
sigGenes=c("outcome")
#a <- coxSummary
for(i in colnames(rt[,2:ncol(rt)])){
	#进行cox回归计算
  formula <- as.formula(paste('outcome ~', i))
	cox <- lrm(formula, data = rt,x=T,y=T)
	#cox <- lrm(outcome~rt[,i], data = rt,x=T,y=T)
	coxSummary <- summary(cox)
  coxP=cox$stats["P"]
	#p<0.05则保留相关基因
	if(!is.na(coxP) && coxP <coxPfilter){
	    sigGenes=c(sigGenes,i)
		outTab=rbind(outTab,
			         cbind(id=i,
			         OR=exp(coxSummary[2,"Effect"]),
			         OR.95L=exp(coxSummary[2,"Lower 0.95"]),
			         OR.95H=exp(coxSummary[2,"Upper 0.95"]),
			         pvalue=coxP)
			        )
	}
}
#输出单因素结果
write.table(outTab,file="GEO.uniCox.txt",sep="\t",row.names=F,quote=F)

#提取单因素显著表达数据
uniSigExp=rt[,sigGenes]
uniSigExp=cbind(id=row.names(uniSigExp),uniSigExp)
write.table(uniSigExp,file="GEO.uniSigExp.txt",sep="\t",row.names=F,quote=F)


############定义森林图函数############
bioForest=function(coxFile=null, forestFile=null, forestCol=null){
	#读取输入文件
	rt <- read.table("GEO.uniCox.txt", header=T, sep="\t", check.names=F, row.names=1)
	gene <- rownames(rt)
	hr <- sprintf("%.3f",rt$"OR")
	hrLow  <- sprintf("%.3f",rt$"OR.95L")
	hrHigh <- sprintf("%.3f",rt$"OR.95H")
	Hazard.ratio <- paste0(hr,"(",hrLow,"-",hrHigh,")")
	pVal <- ifelse(rt$pvalue<0.001, "<0.001", sprintf("%.3f", rt$pvalue))
		
	#输出图形
	height=nrow(rt)/12.5+5
	pdf(file=forestFile, width=7, height=height)
	n <- nrow(rt)
	nRow <- n+1
	ylim <- c(1,nRow)
	layout(matrix(c(1,2),nc=2),width=c(3,2.5))
		
	#绘制森林图左边的基因信息
	xlim = c(0,3)
	par(mar=c(4,2.5,2,1))
	plot(1,xlim=xlim,ylim=ylim,type="n",axes=F,xlab="",ylab="")
	text.cex=0.8
	text(0,n:1,gene,adj=0,cex=text.cex)
	text(1.5-0.5*0.2,n:1,pVal,adj=1,cex=text.cex);text(1.5-0.5*0.2,n+1,'pvalue',cex=text.cex,font=2,adj=1)
	text(3,n:1,Hazard.ratio,adj=1,cex=text.cex);text(3,n+1,'Odds Ratio',cex=text.cex,font=2,adj=1,)
		
	#绘制森林图
	par(mar=c(4,1,2,1),mgp=c(2,0.5,0))
	xlim = c(0,max(as.numeric(hrLow),as.numeric(hrHigh)))
	plot(1,xlim=xlim,ylim=ylim,type="n",axes=F,ylab="",xaxs="i",xlab="Odds Ratio")
	arrows(as.numeric(hrLow),n:1,as.numeric(hrHigh),n:1,angle=90,code=3,length=0.05,col="darkblue",lwd=2.5)
	abline(v=1,col="black",lty=2,lwd=2)
	boxcolor = ifelse(as.numeric(hr) > 1, forestCol[1], forestCol[2])
	points(as.numeric(hr), n:1, pch = 15, col = boxcolor, cex=1.6)
	axis(1)
	dev.off()
}

#调用函数进行森林图可视化
bioForest(coxFile="GEO.uniCox.txt", forestFile="forest.pdf", forestCol=c("red","green"))


