#install.packages("reshape2")
#install.packages("tidyverse")
#install.packages("ggplot2")
#install.packages("RColorBrewer")
#install.packages("grid")


#引用包
library(reshape2)
library(tidyverse)
library(ggplot2)
library(RColorBrewer)
library(grid)

riskFile="risk.TCGA.txt"     #风险文件
cliFile="clinical-PRAD.txt"       #临床数据文件
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\33.cliCircos")     #设置工作目录

#读取输入文件
data=read.table(cliFile, header=T, sep="\t", check.names=F)
data[,"Age"]=ifelse(data[,"Age"]=="unknow", "unknow", ifelse(data[,"Age"]>65,">65","<=65"))
data[,"Gleason_score"]=ifelse(data[,"Gleason_score"]== 6, "Low", 
                             ifelse(data[,"Gleason_score"]==7,"Medium","High"))
riskdata = read.table(riskFile, header=T, sep="\t", check.names=F)

#数据合并
commonsamples=intersect(data[,1],riskdata[,1])
data = data[match(commonsamples,data[,1]),]
riskdata = riskdata[match(commonsamples,riskdata[,1]),]
data$Risk = riskdata$Risk
highnum = sum(data$Risk=="high")
lownum = sum(data$Risk=="low")

#计算高低风险组临床性状的数目
data$Risk[data$Risk=="high"]= sprintf("High\n(%s)",highnum)
data$Risk[data$Risk=="low"]= sprintf("Low\n(%s)",lownum)
piedata = melt(data[,-1],id="Risk")
piedata = piedata[piedata$value!="unknow",]
colnames(piedata) = c("Risk","type","index")
piedata$value = 1
melpiedata = melt(piedata,id=c('Risk','type','index'))
df = dcast(melpiedata,Risk+type+index~variable,length)
df <- df%>%group_by(Risk,type)%>%mutate(ymax = cumsum(value))%>%
     mutate(ymin = ymax - value)%>%
     mutate(ymin=ymin/max(ymax))%>%
    mutate(ymax=ymax/max(ymax))
dfout = df
dfout$Risk = sub('\\n','',dfout$Risk)
#write.table(file="stat.xls", dfout, col.names=T, row.names=F, sep="\t", quote=F)

#定义图形颜色
unitype=levels(df$type)
column.color = rainbow(length(unitype), s=0.7, v=0.7)

#绘制图形
p1 =ggplot(df,aes(fill=index,ymax=ymax,ymin=ymin,label=type,
               xmax=5, xmin=3))+   #圆圈的粗细
  facet_grid(Risk~type,switch="y")+
  theme(panel.spacing = unit(0, "lines"))+
  geom_rect(color="white")+
  coord_polar(theta = 'y')+
  xlim(c(0,5))+ #此范围要包含（xmin,xmax)
  theme(panel.grid = element_blank(),
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank())+
  theme(legend.position="right",legend.box = "horizontal")+
   guides(fill = guide_legend(ncol = 2))+
   theme(legend.title=element_blank())+
  theme(panel.background = element_rect(
    fill = "white", color = "white", size=2)
  )+
  theme(strip.text = element_text(face = "bold", color = "white",
                                  hjust = 0.5, size = 20), # strip.text
    strip.background = element_rect(fill = "black", linetype = "dotted")) #strip.background
 breaks = c()
 values = c()
 for(i in 1:length(unitype)){
   unitypei = unitype[i]
   dfi=df[df$type==unitypei,,drop=F];
   indexi= unique(dfi$index)
   indexi.col = colorRampPalette(c(column.color[i],"white"))(length(indexi)*2)[1:length(indexi)]
   breaks = c(breaks,indexi)
   values = c(values,rev(indexi.col))
}
p=p1+scale_fill_manual(breaks = breaks,values=values) 

#输出图形
pdf(file="clinicalCircos.pdf", width=10, height=4.5)
print(p)
a = 0.08
c = 0.16
b = (1-a-c)/length(unitype)

#在图形中标注卡方检验的p值
for(i in 1:length(unitype)){
  compare.data = spread(data=df[df$type==unitype[i],c('Risk','index','value')], key=Risk, value=value, fill = 0, convert = FALSE, drop = T, sep = NULL)
  chisq.data = chisq.test(compare.data[,-1])
  pi=chisq.data$p.value
  pi=ifelse(pi<0.001,'p<0.001',paste0("p=",sprintf("%.03f",pi)) )
  grid.text(pi, x=a+b*(2*i-1)/2, y=0.1) # middle
}
dev.off()
