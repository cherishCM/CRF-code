library(limma)
# 假设你的基因表达矩阵数据存储在'expression_matrix.csv'文件中
# 基因在行中，样本在列中
expression_matrix <- as.matrix(read.table("geoMatrix.txt", row.names = 1,header = T))

# 假设你的样本分组信息存储在'sample_info.csv'文件中
# 包含样本名称和对应的分组
sample_info <- readxl::read_excel("group.xls")
# 提取不包含第二列缺失值的第一列数据
filtered_data <- sample_info[!is.na(sample_info[, 2]), 1]
# 确保filtered_data是一个向量
filtered_data <- as.vector(filtered_data$ID)
#从基因表达矩阵提取对应样本的数据
filtered_expression_data <- expression_matrix[, filtered_data]

# 导出数据为txt文件
write.table(filtered_expression_data, file = "filtered_geoMatrix.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = NA)
