#install.packages("survival")
#install.packages("caret")
#install.packages("glmnet")
#install.packages("survminer")

#???ð?
library(survival)
library(caret)
library(glmnet)
library(survminer)

modelFile="geneCoef.txt"      #模型公式文件
expFile="IMvigor.exp.txt"     #表达数据文件
cliFile="IMvigor.time.txt"    #生存数据文件
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\35.IMvigor210")     #???ù???Ŀ¼

#读取模型公式文件
coef=read.table(modelFile, header=T, sep="\t", row.names=1)
row.names(coef)=gsub("`", "", row.names(coef))
coxGene=row.names(coef)

#读取表达数据文件(IMvigor)
vigor=read.table(expFile, header=T, sep="\t", check.names=F, row.names=1)
vigor=t(vigor[coxGene,])

#读取生存数据文件(IMvigor)
cli=read.table(cliFile, header=T, sep="\t", check.names=F, row.names=1)
colnames(cli)=c("futime", "fustat")

#合并表达数据和生存数据(IMvigor)
sameSample=intersect(row.names(vigor), row.names(cli))
rt=cbind(cli[sameSample,,drop=F], vigor[sameSample,,drop=F])

#提取模型基因表达量
trainFinalGeneExp=rt[,row.names(coef)]
actCoef=coef[,1]

#????根据模型公式得到病人风险打分
trainFinalGeneExp=scale(trainFinalGeneExp)
myFun=function(x){crossprod(as.numeric(x),actCoef)}
trainScore=apply(trainFinalGeneExp,1,myFun)
outCol=c("futime","fustat",row.names(coef))
outTab=cbind(rt[,outCol],riskScore=as.vector(trainScore))
res.cut=surv_cutpoint(outTab, time = "futime", event = "fustat", variables =c("riskScore"))
cutoff=as.numeric(res.cut$cutpoint[1])
#Risk=as.vector(ifelse(trainScore>cutoff, "high", "low"))
Risk=as.vector(ifelse(trainScore>cutoff, "low", "high"))
outTab=cbind(outTab, Risk)
outTab=cbind(id=rownames(outTab), outTab)
write.table(outTab, file="risk.IMvigor.txt", sep="\t", quote=F, row.names=F)

#????定义生存分析函数
bioSurvival=function(inputFile=null, outFile=null){
	#??ȡ读取输入文件
  rt=read.table(inputFile, header=T, sep="\t", check.names=F)
	#?Ƚ?比较高低风险组生存差异，得到显著性p
	diff=survdiff(Surv(futime, fustat) ~Risk,data = rt)
	pValue=1-pchisq(diff$chisq,df=1)
	if(pValue<0.001){
		pValue="p<0.001"
	}else{
		pValue=paste0("p=",sprintf("%.03f",pValue))
	}
	fit <- survfit(Surv(futime, fustat) ~ Risk, data = rt)
		
	#绘制生存曲线?
	surPlot=ggsurvplot(fit, 
		           data=rt,
		           conf.int=F,
		           pval=pValue,
		           pval.size=6,
		           legend.title="Risk",
		           legend.labs=c("High risk", "Low risk"),
		           xlab="Time(years)",
		           break.time.by = 2,
		           palette=c("red", "blue"),
		           risk.table=F,
		       	   risk.table.title="",
		           risk.table.col = "strata",
		           risk.table.height=.25)
	#??  ?输出图形f  
	pdf(file=outFile, width=4.5, height=4, onefile = FALSE)
	print(surPlot)
	dev.off()
}

#????调用函数绘制生存曲线
bioSurvival(inputFile="risk.IMvigor.txt", outFile="sur.IMvigor.pdf")
