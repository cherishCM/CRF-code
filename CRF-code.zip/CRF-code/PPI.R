countFilter=10     #设置邻接节点的过滤条件
inputFile="string_interactions_short.tsv"            
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\15.PPI")     

#??ȡ?????ļ?
rt=read.table(inputFile, header=T, sep="\t", check.names=FALSE, comment.char="")
tb=table(c(as.vector(rt[,1]), as.vector(rt[,2])))
tb=sort(tb, decreasing=T)

#输出网络核心基因
outTab=as.data.frame(tb)
outTab=outTab[outTab[,2]>=countFilter,]
colnames(outTab)=c("Gene","Count")
write.table(outTab,file="hubGene.txt",sep="\t",quote=F,row.names=F)
showNum=nrow(outTab)
n=as.matrix(tb)[1:showNum,]

#绘制核心基因柱状图
pdf(file="barplot.pdf", width=8, height=8)
par(mar=c(5,6,1,2),xpd=T)
bar=barplot(n,horiz=TRUE,col="skyblue",names=FALSE,xlim=c(0,ceiling(max(n)/5)*5),xlab="Number of adjacent nodes")
text(x=n*0.935,y=bar,n)     #在图形中加入邻接节点数目
text(x=-0.2,y=bar,label=names(n),xpd=T,pos=2)     #在图形中加入邻基因名称
dev.off()
