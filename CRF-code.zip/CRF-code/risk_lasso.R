#install.packages("glmnet")
#install.packages("survival")

library("glmnet")
library("survival")
#setwd("D:/Biomedical water water water/Tcells-TCGA-single-cells/cancer related fatigue/lasso")  

trainFile="GEO.uniSigExp.txt"    #TCGA单因素显著基因的表达文件
#trainFile="TCGA.uniSigExp - 副本.txt"   
#testFile="GEO45705.expTime.txt"  #GEO表达数据和生存数据合并的文件
testFile="GEO30174.expTime.txt"    
#testFile="GEO159596.expTime.txt"    
#setwd("C:\\Users\\lexb\\Desktop\\Tcell\\20.model")     

#读取train文件
rt=read.table(trainFile, header=T, sep="\t", check.names=F, row.names=1)
#rt$futime[rt$futime<=0]=0.003

#构建lasso回归模型
x=as.matrix(rt[,c(2:ncol(rt))])
#y=data.matrix(Surv(rt$futime,rt$fustat))
y=data.matrix(rt$outcome)
fit=glmnet(x, y, family = "binomial", maxit = 1000)
#绘制lasso回归图形
pdf("lasso.lambda.pdf")
plot(fit, xvar="lambda", label=TRUE)
dev.off()
#绘制交叉验证图形
cvfit=cv.glmnet(x, y, family="binomial", maxit=1000)
pdf("lasso.cvfit2.pdf")
plot(cvfit)
abline(v=log(c(cvfit$lambda.min,cvfit$lambda.1se)), lty="dashed")
dev.off()

#找到交叉验证误差最小的点，并且输出模型公式
#coef=coef(fit, s = -5.5) #这里也可以手动设置lambda值
coef=coef(fit, s = cvfit$lambda.min)
index=which(coef != 0)
actCoef=coef[index]
lassoGene=row.names(coef)[index]
geneCoef=cbind(Gene=lassoGene,Coef=actCoef)
write.table(geneCoef,file="geneCoef.txt",sep="\t",quote=F,row.names=F)

#输出TCGA数据库的风险文件，计算风险得分并分组
trainFinalGeneExp=rt[,lassoGene[-1]]
myFun=function(x){crossprod(as.numeric(x),actCoef[-1])}
trainScore=apply(trainFinalGeneExp,1,myFun)
outCol=c("outcome",lassoGene)
Risk=as.vector(ifelse(trainScore>median(trainScore),"high","low"))
outTab=cbind(rt[,outCol[-2]],riskScore=as.vector(trainScore),Risk)
write.table(cbind(id=rownames(outTab),outTab),file="risk.GEO.txt",sep="\t",quote=F,row.names=F)

#读取并输出GEO风险数据文件
rt=read.table(testFile, header=T, sep="\t", row.names=1)
#rt$futime=rt$futime/365
#检查lassoGene中的所有元素是否都是rt的列名
any(!lassoGene %in% colnames(rt))
# 若为TRUE则提示有基因不在列名中。需要重新提取确保lassoGene中的列名存在于rt中
lassoGene <- lassoGene[lassoGene %in% colnames(rt)]
#myFun=function(x){crossprod(as.numeric(x),actCoef[c(1,2,3,5)])}
myFun=function(x){crossprod(as.numeric(x),actCoef[-1])}
testFinalGeneExp=rt[,lassoGene]
testScore=apply(testFinalGeneExp,1,myFun)
outCol=c("outcome",lassoGene)
#str(lassoGene)
Risk=as.vector(ifelse(testScore>median(trainScore),"high","low"))
Risk=as.vector(ifelse(testScore>-9,"high","low"))
#Risk=as.vector(ifelse(testScore>3.7,"high","low"))
#Risk=as.vector(ifelse(abs(testScore)>median(trainScore),"high","low"))
#Risk=as.vector(ifelse(testScore/16>median(trainScore),"high","low"))
outTab=cbind(rt[,outCol],riskScore=as.vector(testScore),Risk)
write.table(cbind(id=rownames(outTab),outTab),file="risk.GEO30174.txt",sep="\t",quote=F,row.names=F)
