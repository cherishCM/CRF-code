
#if (!require("BiocManager", quietly = TRUE))
#  install.packages("BiocManager")

#BiocManager::install("ConsensusClusterPlus")

#引用包
library(limma)
library(survival)
library(ConsensusClusterPlus)

#设置工作目录
getwd()
workDir="D:/Biomedical water water water/Tcells-TCGA-single-cells/cancer related fatigue/ConsensusClusterPlus/GEO"
setwd(workDir)

#读入
data=read.table("fatigue-GEO30174-Matrix.txt", header=T, sep="\t", check.names=F)
#转化为matrix
data=as.matrix(data)
rownames(data)=data[,1]
exp=data[,2:ncol(data)]
dimnames=list(rownames(exp),colnames(exp))
data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
data=avereps(data)
#dimnames=list(rownames(data), colnames(data))
#data=matrix(as.numeric(as.matrix(data)), nrow=nrow(data), dimnames=dimnames)

#正常和肿瘤数目,第14,15字符,01-09是癌症，10-19是正常，20-29是癌旁
#group=sapply(strsplit(colnames(data),"\\-"), "[", 4)
#group=sapply(strsplit(group,""), "[", 1)
#根据正常和肿瘤排序
#data = data[,group == 0]

#读取多因素cox基因的表达矩阵
multicoxgene=read.table("GEO.uniCox.txt", header=T, sep="\t", check.names=F,row.names = 1)
data = data[rownames(multicoxgene),]

#对样品进行分型
#maxK, 最大的K值，形成一系列梯度
#pItem, 选择80%的样本进行重复抽样
#pfeature, 选择80%的基因进行重复抽样
#reps, 重复抽样的数目，先设置为100，结果不错再设置为1000
#clusterAlg, 聚类的算法,hc,pam,km
#distanc, 距离矩阵的算法,pearson,spearman,euclidean
#title, 输出结果的文件夹名字，包含了输出的图片
#seed, 随机种子，用于固定结果

results=ConsensusClusterPlus(data,
                             maxK=9,
                             reps=100,
                             pItem=0.8,
                             pFeature=1,
                             title=workDir,
                             clusterAlg="pam",
                             distance="euclidean",
                             seed=123,
                             plot="png")

#输出分型结果
clusterNum=3      #分成几个亚型
cluster=results[[clusterNum]][["consensusClass"]]
cluster=as.data.frame(cluster)
colnames(cluster)=c("cluster")
letter=c("A","B","C","D","E","F","G","H","I","J")
uniqClu=levels(factor(cluster$cluster))
cluster$cluster=letter[match(cluster$cluster, uniqClu)]
clusterOut=rbind(ID=colnames(cluster), cluster)
write.table(clusterOut, file="cluster.txt", sep="\t", quote=F, col.names=F)
