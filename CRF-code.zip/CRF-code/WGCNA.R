
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install(c("GO.db", "preprocessCore", "impute","limma"),force =T)

#install.packages(c("matrixStats", "Hmisc", "foreach", "doParallel", "fastcluster", "dynamicTreeCut", "survival")) 
#install.packages("WGCNA")

#加载R包
library(limma)
library(WGCNA)

#工作目录
#setwd("F:/3SP/37WGCNA")    
####数据准备####
#读入
data=read.table("TCGA-PRAD.txt", header=T, sep="\t", check.names=F)
#转化为matrix
data=as.matrix(data)
rownames(data)=data[,1]
exp=data[,2:ncol(data)]
dimnames=list(rownames(exp),colnames(exp))
data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
data=avereps(data)
#dimnames=list(rownames(data), colnames(data))
#data=matrix(as.numeric(as.matrix(data)), nrow=nrow(data), dimnames=dimnames)

#正常和肿瘤数目,第14,15字符,01-09是癌症，10-19是正常，20-29是癌旁
group=sapply(strsplit(colnames(data),"\\-"), "[", 4)
group=sapply(strsplit(group,""), "[", 1)
#将2变为1
group=gsub("2", "1", group)
#根据正常和肿瘤排序
data = data[,group == 0]

#修改样本名
#样本名仅保留前12字符
colnames(data)=substr(colnames(data),1,12)
#将.改为-
colnames(data) = gsub('[.]', '-', colnames(data))
#去除低表达的基因
data=data[rowMeans(data)>0.5,]

#读入临床数据
cli=read.table("clinical-PRAD.txt", header=T, sep="\t", check.names=F, row.names=1)
#共有样本
sameSample=intersect(row.names(cli), colnames(data))
#分别提取共有样本
cli = cli[sameSample,]
data = data[,sameSample]
dim(data)
#选择波动最大的前25%的基因进行WGCNA分析
#纳入的基因不易过多，否则需要运行很长一段时间，通常用5000个基因进行分析。
selectGenes=names(tail(sort(apply(data,1,sd)), n=round(nrow(data)*0.3)))
data=data[selectGenes,]
dim(data)
#转置
datExpr0=t(data)

#检查缺失值和识别离群值（异常值）
#如果gsg$allOK的结果为TRUE，证明没有缺失值，可以直接下一步。
#如果为FALSE，则需要用以下函数进行删除缺失值。
gsg = goodSamplesGenes(datExpr0, verbose = 3)
gsg$allOK
if (!gsg$allOK){
  if (sum(!gsg$goodGenes)>0)
    printFlush(paste("Removing genes:", paste(names(datExpr0)[!gsg$goodGenes], collapse = ", ")))
  if (sum(!gsg$goodSamples)>0)
    printFlush(paste("Removing samples:", paste(rownames(datExpr0)[!gsg$goodSamples], collapse = ", ")))
  datExpr0 = datExpr0[gsg$goodSamples, gsg$goodGenes]
}
####选择适当样本####
#聚类所有样本，观察是否有离群值或异常值。
#删除剪切线以下的样品，查看1_sample_cluster.pdf图片，选取离群值，
#如果不想要删除可以将cutHeight设置的高些
sampleTree = hclust(dist(datExpr0), method = "average")
#画图1
pdf(file = "1_sample_cluster.1.pdf", width = 12, height = 9)
par(cex = 0.6)
par(mar = c(0,4,2,0))
plot(sampleTree, main = "Sample clustering to detect outliers", sub="", xlab="", 
     cex.lab = 1.5, cex.axis = 1.5, cex.main = 2)
dev.off()

#删除剪切线以下的样品，查看1_sample_cluster.1.pdf图片，选取离群值，
#如果不想要删除可以将cutHeight设置的高些
cutHeight = 100000
#画图2
pdf(file = "1_sample_cluster.2.pdf", width = 12, height = 9)
par(cex = 0.6)
par(mar = c(0,4,2,0))
plot(sampleTree, main = "Sample clustering to detect outliers", sub="", xlab="", 
     cex.lab = 1.5, cex.axis = 1.5, cex.main = 2)
abline(h = cutHeight, col = "red")
dev.off()

#剪切
clust = cutreeStatic(sampleTree, cutHeight = cutHeight, minSize = 10)
table(clust)
keepSamples = (clust==1)
datExpr0 = datExpr0[keepSamples, ]
dim(data)
dim(datExpr0)
####选择合适的power值####
#构建自动化网络和检测模块
#power值散点图，选择软阈值
enableWGCNAThreads()   #多线程工作
powers = c(1:20)       #幂指数范围1:20
sft = pickSoftThreshold(datExpr0, powerVector = powers, verbose = 5)
pdf(file="2_scale_independence.pdf",width=9,height=5)
par(mfrow = c(1,2))

cex1 = 0.9 #可以修改，这是选择power的阈值，如果power值为NA则可以修改
#拟合指数与power值散点图，无标度拓扑拟合指数
#一般选择在0.9以上的，第一个达到0.9以上数值。
plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
     xlab="Soft Threshold (power)",ylab="Scale Free Topology Model Fit,signed R^2",type="n",
     main = paste("Scale independence"));
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
     labels=powers,cex=cex1,col="red");
abline(h=cex1,col="red")

#越平滑越好，
#平均连通性与power值散点图
plot(sft$fitIndices[,1], sft$fitIndices[,5],
     xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n",
     main = paste("Mean connectivity"))
text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, cex=cex1,col="red")
dev.off()

#邻接矩阵转换
#查看最佳power值
#如果显示的结果为 NA，则表明系统无法给出合适的软阈值，这时候就需要自己挑选软阈值。
sft
softPower =sft$powerEstimate
adjacency = adjacency(datExpr0, power = softPower)
softPower #系统自动推荐power值

#如无合适软阈值时，可以按以下条件选择：
if (is.na(power)){ 
  power = ifelse(nSamples<20, ifelse(type == "unsigned", 9, 18), 
                 ifelse(nSamples<30, ifelse(type == "unsigned", 8, 16), 
                        ifelse(nSamples<40, ifelse(type == "unsigned", 7, 14), 
                               ifelse(type == "unsigned", 6, 12))        
                 ) 
  ) 
}

####进行WGCNA分析####
#TOM矩阵
TOM = TOMsimilarity(adjacency)
dissTOM = 1-TOM

#基因聚类
geneTree = hclust(as.dist(dissTOM), method = "average");
pdf(file="3_gene_clustering.pdf",width=12,height=9)
plot(geneTree, xlab="", sub="", main = "Gene clustering on TOM-based dissimilarity",
     labels = FALSE, hang = 0.04)
dev.off()

#动态剪切模块识别
#模块基因数目
minModuleSize=100#设置最小模块基因数      
dynamicMods = cutreeDynamic(dendro = geneTree, distM = dissTOM,
                            deepSplit = 2, pamRespectsDendro = FALSE,
                            minClusterSize = minModuleSize);
table(dynamicMods)
dynamicColors = labels2colors(dynamicMods)
table(dynamicColors)
pdf(file="4_Dynamic_Tree.pdf",width=8,height=6)
plotDendroAndColors(geneTree, dynamicColors, "Dynamic Tree Cut",
                    dendroLabels = FALSE, hang = 0.03,
                    addGuide = TRUE, guideHang = 0.05,
                    main = "Gene dendrogram and module colors")
dev.off()

#查找相似模块聚类
#通过计算模块的代表性模式和模块之间的定量相似性评估，合并表达图谱相似的模块
MEList = moduleEigengenes(datExpr0, colors = dynamicColors)
MEs = MEList$eigengenes
MEDiss = 1-cor(MEs);
METree = hclust(as.dist(MEDiss), method = "average")
pdf(file="5_Clustering_module.pdf",width=7,height=7)
plot(METree, main = "Clustering of module eigengenes",
     xlab = "", sub = "")
MEDissThres = 0.3  #剪切高度可修改，将小于0.3的模块进行合并
abline(h=MEDissThres, col = "red")
dev.off()

#相似模块合并
merge = mergeCloseModules(datExpr0, dynamicColors, cutHeight = MEDissThres, verbose = 3)
mergedColors = merge$colors
mergedMEs = merge$newMEs
pdf(file="6_merged_dynamic.pdf", width = 8, height = 6)
plotDendroAndColors(geneTree, mergedColors,"Dynamic Tree Cut",
                    dendroLabels = FALSE, hang = 0.03,
                    addGuide = TRUE, guideHang = 0.05,
                    main = "Gene dendrogram and module colors")
dev.off()
moduleColors = mergedColors
table(moduleColors)
colorOrder = c("grey", standardColors(50))
moduleLabels = match(moduleColors, colorOrder)-1
MEs = mergedMEs


####构建基因模块与临床特征相关性####
#提取共有样本
#读入临床数据
cli2=read.table("clinical-PRAD.txt", header=T, sep="\t", check.names=F, row.names=1)
#共有样本
sameSample2=intersect(row.names(cli2), rownames(MEs))
#分别提取共有样本
MEs=MEs[sameSample2,]
datTraits=cli2[sameSample2,]
nGenes = ncol(datExpr0)
nSamples = nrow(datExpr0)
#相关性分析
moduleTraitCor = cor(MEs, datTraits, use = "p")
moduleTraitPvalue = corPvalueStudent(moduleTraitCor, nSamples)
pdf(file="7_Module_trait.pdf", width=6.5, height=5.5)
textMatrix = paste(signif(moduleTraitCor, 2), "\n(",
                   signif(moduleTraitPvalue, 1), ")", sep = "")
dim(textMatrix) = dim(moduleTraitCor)
par(mar = c(5, 10, 3, 3))
labeledHeatmap(Matrix = moduleTraitCor,
               xLabels = names(datTraits),
               yLabels = names(MEs),
               ySymbols = names(MEs),
               colorLabels = FALSE,
               colors = blueWhiteRed(50),
               textMatrix = textMatrix,
               setStdMargins = FALSE,
               cex.text = 0.5,
               zlim = c(-1,1),
               main = paste("Module-trait relationships"))
dev.off()

#基因所在的模块进行导出
probes = colnames(datExpr0)
geneInfo0 = data.frame(probes= probes,
                       moduleColor = moduleColors)
geneOrder =order(geneInfo0$moduleColor)
geneInfo = geneInfo0[geneOrder, ]
write.table(geneInfo, file = "module_all.txt",sep="\t",row.names=F,quote=F)

#输出每个模块的基因
for (mod in 1:nrow(table(moduleColors))){  
  modules = names(table(moduleColors))[mod]
  probes = colnames(datExpr0)
  inModule = (moduleColors == modules)
  modGenes = probes[inModule]
  write.table(modGenes, file =paste0("module_",modules,".txt"),sep="\t",row.names=F,col.names=F,quote=F)
}

#运行以下代码可视化GS和MM
#GS：所有基因表达谱与这个模块的eigengene的相关性（cor）。
#每一个值代表这个基因与模块之间的关系。如果这个值的绝对值接近0，
#那么这个基因就不是这个模块中的一部分，如果这个值的绝对值接近1，那么这个基因就与这个模块高度相关。
#MM：基因和表型性状比如体重之间的相关性的绝对值。
module = "grey"
Selectedclinical = "Gleason_score"
Selectedclinical2 = "Gleason_score"

#以MEturquoise，Grade为例
Selectedclinical = as.data.frame(datTraits[,Selectedclinical]);
names(Selectedclinical) = "Selectedclinical";
modNames = substring(names(MEs), 3)
datExpr1 = datExpr0[rownames(MEs),]
geneModuleMembership = as.data.frame(cor(datExpr1, MEs, use = "p"));
MMPvalue = as.data.frame(corPvalueStudent(as.matrix(geneModuleMembership), nSamples));
names(geneModuleMembership) = paste("MM", modNames, sep="");
names(MMPvalue) = paste("p.MM", modNames, sep="");
geneTraitSignificance = as.data.frame(cor(datExpr1, Selectedclinical, use = "p"));
GSPvalue = as.data.frame(corPvalueStudent(as.matrix(geneTraitSignificance), nSamples));
names(geneTraitSignificance) = paste("GS.", names(Selectedclinical), sep="");
names(GSPvalue) = paste("p.GS.", names(Selectedclinical), sep="");

#绘制相关性散点图
column = match(module, modNames)
moduleGenes = moduleColors==module
outPdf=paste(Selectedclinical2,"_", module, ".pdf",sep="")
pdf(file=outPdf,width=7,height=7)
verboseScatterplot(abs(geneModuleMembership[moduleGenes, column]),
                   abs(geneTraitSignificance[moduleGenes, 1]),
                   xlab = paste("Module Membership in", module, "module"),
                   ylab = paste("Gene significance for ", Selectedclinical2,sep=""),
                   main = paste("Module membership vs. gene significance\n"),
                   cex.main = 1.2, cex.lab = 1.2, cex.axis = 1.2, col = module)
dev.off()



#输出模块的核心基因
#合并
datMM=cbind(geneModuleMembership[,paste("MM", module, sep="")], geneTraitSignificance)
colnames(datMM)[1] = paste("MM", module, sep="")
#设置重要性和相关性的阈值
geneSigFilter=0.145
moduleSigFilter=0.4
#筛选
datMM=datMM[abs(datMM[,ncol(datMM)])>geneSigFilter,]
datMM=datMM[abs(datMM[,1])>moduleSigFilter,]
#导出
write.table(row.names(datMM), file =paste0("hubGenes",module,".txt"),sep="\t",row.names=F,col.names=F,quote=F)
