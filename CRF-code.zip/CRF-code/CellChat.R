#if (!require("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")
#BiocManager::install("ComplexHeatmap")

#install.packages("dplyr")
#install.packages("NMF")
#install.packages("patchwork")
#install.packages("igraph")
#install.packages("ggplot2")
#install.packages("ggalluvial")
#install.packages("circlize")
#install.packages("svglite")

#install.packages("devtools")
#library(devtools)
#devtools::install_github("sqjin/CellChat")



#???ð?
library(limma)
library(NMF)
library(ggplot2)
library(ggalluvial)
library(svglite)
library(CellChat)

#expFile="04.expMatirx.txt"     #?????????ļ?
expFile="04.expMatirx-UMAP.txt"
#annFile="04.cellAnn.txt"       #ϸ??ע???ļ?
annFile="04.cellAnn-UMAP.txt"
geneFile="hubGenes.csv"        #?????б??ļ?
#setwd("C:\\Users\\lexb\\Desktop\\communication\\19.CellChat")      #???ù???Ŀ¼

#??ȡ读取表达数据文件，并对数据文件进行处理??ݽ??д???
rt=read.table(expFile, header=T, sep="\t", check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp), colnames(exp))
data=matrix(as.numeric(as.matrix(exp)), nrow=nrow(exp), dimnames=dimnames)
data=avereps(data)
data=data[rowMeans(data)>0,]

#??取细胞注释文?ļ?
meta=read.table(annFile, header=T, sep="\t", check.names=F, row.names=1)

#?创建cellchat对象???
cellchat <- createCellChat(object = data, meta = meta, group.by = "labels")
cellchat <- setIdent(cellchat, ident.use="labels")
groupSize <- as.numeric(table(cellchat@idents))      #ÿ??每个细胞类型的细胞数目???Ŀ
rm(exp)
#??导入配体受体数据库?ݿ?
CellChatDB <- CellChatDB.human       #????如果物种是小鼠则改成CellChatDB.mouse
CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling")
cellchat@DB <- CellChatDB.use

#?鿴??查看配体受体的类型?????
pdf(file="COMM01.DatabaseCategory.pdf", width=7, height=5)
showDatabaseCategory(CellChatDB)
dev.off()

#?Ա对表达数据进行预处理??
cellchat <- subsetData(cellchat)
cellchat <- identifyOverExpressedGenes(cellchat)      #ʶ??识别每种细胞中的过表达?Ļ???
cellchat <- identifyOverExpressedInteractions(cellchat)      #ʶ?识别基因的相关性໥????
cellchat <- projectData(cellchat, PPI.human)  

#???计算细胞通讯概率???
cellchat <- computeCommunProb(cellchat)
#??过滤小于10个细胞的细胞通讯?ͨѶ
cellchat <- filterCommunication(cellchat, min.cells = 10)
#??输出细胞间的通讯关系??ϵ
df.net=subsetCommunication(cellchat)
write.table(file="COMM02.Comm.network.xls", df.net, sep="\t", row.names=F, quote=F)

#??在信号通路水平进一步推测细胞间的通讯，推断通路水平的互作网络ƽ?Ļ???????
cellchat <- computeCommunProbPathway(cellchat)

#?Լ?整合计算结果，展示细胞整体通讯状态??ϸ??ͨѶ״̬
cellchat <- aggregateNet(cellchat)
#???输出细胞通讯图形??(??互作数量图形??)
pdf(file="COMM03.cellNetworkCount.pdf", width=7, height=6)
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Number of interactions")
dev.off()
#????输出细胞通讯图像???ǿ互作强度图像??)
pdf(file="COMM04.cellNetworkWeight.pdf", width=7, height=6)
netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Interaction strength")
dev.off()

#??ϸ??分细胞类型进行展示（提取单个细胞，观察这个细胞和其他细胞的通讯）????ͨѶ)
pdf(file="COMM05.singleCell.pdf", width=8, height=6)
weight_mat <- cellchat@net$weight
par(mfrow = c(2,3), mgp=c(0,0,0), xpd=TRUE)
for (cel in unique(cellchat@idents)){
  cir_mat <- matrix(0, nrow = nrow(weight_mat), ncol = ncol(weight_mat), dimnames = dimnames(weight_mat))
  cir_mat[cel, ] <- weight_mat[cel, ]
  netVisual_circle( cir_mat, vertex.weight= groupSize, weight.scale= T,edge.weight.max = max(weight_mat), vertex.label.cex=0.8,title.name=cel)
}
dev.off()

#???绘制受体配对气泡图???ͼ
pdf(file=paste0("COMM06.bubble.pdf"), width=18, height=15.5)
netVisual_bubble(cellchat, remove.isolate = FALSE, angle.x = 45)
dev.off()

#??ȡ读取基因列表文件，找到核心基因参与的细胞通讯，获取核心基因的通路????ͨ·
geneRT=read.csv(geneFile, header=T, sep=",", check.names=F)
hubGenes=as.vector(geneRT[,1])
def.hub=df.net[((df.net$ligand %in% hubGenes) | (df.net$receptor %in% hubGenes)),]
write.table(file="COMM07.Comm.hubNetwork.xls", def.hub, sep="\t", row.names=F, quote=F)

#ͨ·ˮĿ?通路水平可视??ӻ?
cellchat@netP$pathways     #չʾ???展示所有相关通路名???
pathways.show="OSM"       #ѡ??Ҫ选择需要展示的通路?)
#ͨϸ??ͨ通路的细通讯通?ͨѶͼ
pdf(file=paste0("COMM08.", pathways.show , ".circle.pdf"), width=8, height=6)
circle=netVisual_aggregate(cellchat, signaling=pathways.show, layout="circle", vertex.size = groupSize)
print(circle)
dev.off()
#ʹ?使用层次图展示通路的细胞通讯??ϸ??ͨѶ
pdf(file=paste0("COMM09.", pathways.show , ".hierarchy.pdf"), width=12, height=6)
hierarchy=netVisual_aggregate(cellchat, signaling=pathways.show, layout="hierarchy",  vertex.receiver=seq(1,4), vertex.size = groupSize)
print(hierarchy)
dev.off()
#ϸ?细胞通讯的热图???ͼ
pdf(file=paste0("COMM10.", pathways.show , ".heatmap.pdf"), width=8, height=6)
heatmap=netVisual_heatmap(cellchat, signaling=pathways.show, color.heatmap = "Reds", measure= 'weight')	
print(heatmap)
dev.off()
#ϸ??细胞作用类型分析???
pdf(file=paste0("COMM11.", pathways.show , ".netAnalysis.pdf"), width=6, height=5)
cellchat <- netAnalysis_computeCentrality(cellchat, slot.name = "netP") 
netAnalysis=netAnalysis_signalingRole_network(cellchat, signaling =pathways.show, width = 8, height = 5, font.size = 12)
print(netAnalysis)
dev.off()

#?查看哪些配体和受体对在通路中起作用（配体受体对的贡献程度）????ԵĹ??׳̶?)
pdf(file=paste0("COMM12.", pathways.show , ".contribution.pdf"), width=8, height=6)
contribution=netAnalysis_contribution(cellchat, signaling= pathways.show)
print(contribution)
dev.off()
#?鿴查看通路中互作基因的表达水平??ˮƽ
pdf(file=paste0("COMM13.", pathways.show , ".geneExp.pdf"), width=8, height=6)
geneExp=plotGeneExpression(cellchat, signaling=pathways.show)
print(geneExp)
dev.off()

#?配体受体对水平的细胞通讯展示??ͨѶչʾ
pairLR <- extractEnrichedLR(cellchat, signaling=pathways.show, geneLR.return=FALSE)
pdf(file=paste0("COMM14.", pathways.show , ".pairLR.pdf"), width=9, height=8)
pairCircos=netVisual_individual(cellchat, signaling=pathways.show, pairLR.use=pairLR[1] , layout="circle" )
print(pairCircos)
dev.off()
#??ͨ对通路中的配体受体对进行循环，以和弦图的形式展示??ʽչʾ
for(i in 1:nrow(pairLR)){
  pdf(file=paste0("COMM15.", pairLR[i,], ".pairLR.pdf"), width=8, height=6)
  pairChord=netVisual_individual(cellchat, signaling=pathways.show, pairLR.use=pairLR[i,], layout="chord" )
  print(pairChord)
  dev.off()
}

