#install.packages("survival")
#install.packages("survminer")

library(survival)
library(survminer)
getwd()
setwd("D:/Biomedical water water water/Tcells-TCGA-single-cells/cancer related fatigue/survival/")     #???ù???Ŀ¼

#?????????????ĺ???
bioSurvival=function(inputFile=null, outFile=null){
	#??ȡ?????ļ?
	rt=read.table(inputFile, header=T, sep="\t", check.names=F)
	#?Ƚϸߵͷ??????????????죬?õ??????????Ե?pvalue
	diff=survdiff(Surv(futime, fustat) ~ Risk, data = rt)
	pValue=1-pchisq(diff$chisq,df=1)
	if(pValue<0.001){
		pValue="p<0.001"
	}else{
		pValue=paste0("p=",sprintf("%.03f",pValue))
	}
	fit <- survfit(Surv(futime, fustat) ~ Risk, data = rt)
		
	
	surPlot=ggsurvplot(fit, 
		           data=rt,
		           conf.int=F,
		           pval=pValue,
		           pval.size=6,
		           legend.title="Risk",
		           legend.labs=c("High risk", "Low risk"),
		           #legend.labs=c("Low risk", "High risk"),
		           xlab="Time(years)",
		           ylab="Overall survival",
		           break.time.by = 2,
		           palette=c("red", "blue"),
		           #palette=c("blue", "red"),
		           risk.table=TRUE,
		           risk.table.title="",
		           risk.table.height=.25)

	pdf(file=outFile, width=6, height=5, onefile=FALSE)
	print(surPlot)
	dev.off()
}
bioSurvival(inputFile="risk.TCGA.txt", outFile="risk_survival.TCGA.pdf")
bioSurvival(inputFile="risk.GEO84437.txt", outFile="risk_survival.GEO84437.pdf")
bioSurvival(inputFile="risk.GEO159596.txt", outFile="risk_survival.GEO159596.pdf")
